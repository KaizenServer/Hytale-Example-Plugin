# CLAUDE.md — AI Workflow System Entry Point

Read this file completely before doing anything else in this project.

---

## STEP 0 — Read these files before starting any work

Read in this order. Do not skip any.

1. `problem_solving/CLAUDE_BIBLE.md` — rules derived from real mistakes. Apply them actively.
2. `problem_solving/SESSION_PRIMER.md` — how we handle problems and verification.
3. List the contents of `claude_methodologies/` — know what methodologies exist.

**Do not respond to the user's request until you have read all three.**

---

## WHAT COUNTS AS A TASK

Every one of these is a task and requires the full task_kickoff protocol:

- Research or investigation (even if it looks like a question)
- Generating a prompt, template, or document
- Analysing a file or document
- Writing or modifying code
- Any request that produces an output or modifies a file
- Any question that requires synthesis, comparison, or multi-step reasoning

**If you are unsure, treat it as a task.**

A task is NOT: a clarification question, a yes/no factual lookup, a direct file read with no synthesis.

---

## PROTOCOL FOR EVERY TASK

Follow `claude_methodologies/task_kickoff/PROMPT.md`. In brief:

1. **Understand** — confirm what the goal is, where the work happens, what the output is
2. **Check** — does a `PROCESS_REPORT.md` / `STATUS_LOG.md` already exist in the source folder?
   - Yes → continuation: read both, report last known state, resume
   - No → new task: proceed to step 3
3. **Track** — create `PROCESS_REPORT.md` and `STATUS_LOG.md` in the source folder before executing anything
4. **Plan** — present the approach to the user. Do not execute until they approve.
5. **Execute** — update `STATUS_LOG.md` at each milestone
6. **Log mistakes immediately** — wrong assumption or misdiagnosis → add to `CLAUDE_BIBLE.md` now, not at end of session
7. **Close** — apply `claude_methodologies/session_closure/PROMPT.md` at session end
8. **Log usage** — append one row to the methodology's `USAGE_LOG.md`

**Steps 1–3 happen before any code or commands are run.**
**Step 4 requires user approval before step 5 begins.**

---

## SAFETY RULES (from CLAUDE_BIBLE — critical ones inline)

- **Check before declaring.** Never say a file is missing, broken, or incomplete without verifying it first. `ls` it.
- **Diagnose before fixing.** Read the full error. Trace it to the exact line. A fix on the wrong line is worse than no fix.
- **Never use agents to read local files on Windows.** Agents run bash internally and trigger Microsoft Store prompts for Unix commands. Use the Read tool or PowerShell directly.
- **Verify agents independently.** After an agent completes a batch task, check the output yourself — do not trust the agent's self-reported status.

Full rules with context: `problem_solving/CLAUDE_BIBLE.md`

---

## SESSION CLOSURE

When the session is ending or the task is complete:

→ Apply `claude_methodologies/session_closure/PROMPT.md` — all 8 steps, in order. Do not skip any.

The 8 steps are:
1. Self-report (before looking at folders)
2. Task genealogy (parent vs sub-task)
3. Folder inspection
4. Cross-check self-report vs folders
5. Methodology identification
6. Documentation (PROCESS_REPORT + STATUS_LOG)
7. Problem log (CLAUDE_BIBLE updates)
8. Methodology usage logs

---

## AVAILABLE METHODOLOGIES

| Methodology | When to use |
|---|---|
| `task_kickoff/` | Start of every task |
| `session_closure/` | End of every session |
| `web_research/` | Intensive web research with multi-query synthesis |
| `chat_rescuing/` | Recovering from a crashed or interrupted session |
